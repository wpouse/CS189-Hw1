Name: Winston Pouse
Student ID: 23491652

Instructions: Place the IPython Notebook alongside the 'data' folder and then running everything in order.
Note that Problem 3 takes a while to run. To shorten runtime C values from around 1E-3 and above and below 1E-9 can be removed since the optimal C value is already known
